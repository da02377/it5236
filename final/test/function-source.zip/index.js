exports.toFahr = (req, res) => {
  let num1 = parseFloat(req.body.num1);
  let result = "" + ((num1 * (9/5)) + 32);

  if (!isNaN(result)) {
      res.status(200).send(result);
  } 
  else if (isNaN(num1)) {
      res.status(400).send("bad request");
  } 
  else {
      res.status(400).send("bad request");;
  }
};